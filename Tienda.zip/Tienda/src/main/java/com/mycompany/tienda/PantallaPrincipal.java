package com.mycompany.tienda;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Conej
 */
class PantallaPrincipal extends JFrame {

    public PantallaPrincipal(Usuario usuarioAutenticado) {
        // Inicializar componentes
        Inventario inventario = new Inventario();
        Carrito carrito = new Carrito();

        // Configuración de la ventana
        setTitle("Tienda Online - " + usuarioAutenticado.getNombre());
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel de botones
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Crear botones
        JButton verProductosButton = new JButton("Ver Productos");
        JButton verCarritoButton = new JButton("Ver Carrito");
        JButton verPerfilButton = new JButton("Ver Perfil");

        // Listeners de botones
        verProductosButton.addActionListener(e -> {
            VerProductos verProductos = new VerProductos(inventario, carrito);
            verProductos.setVisible(true);
        });

        verCarritoButton.addActionListener(e -> {
            VerCarrito verCarrito = new VerCarrito(carrito);
            verCarrito.setVisible(true);
        });

        verPerfilButton.addActionListener(e -> {
            VerPerfil verPerfil = new VerPerfil(usuarioAutenticado);
            verPerfil.setVisible(true);
        });

        // Agregar botones al panel
        panel.add(verProductosButton);
        panel.add(verCarritoButton);
        panel.add(verPerfilButton);

        add(panel);
    }
}
