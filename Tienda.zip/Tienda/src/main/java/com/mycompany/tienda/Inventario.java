/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author Conej
 */
import java.util.ArrayList;
import java.util.List;

public class Inventario {

    private List<Producto> productos;

    public Inventario() {
        this.productos = new ArrayList<>();
        cargarProductosPredeterminados();
    }

    public final void cargarProductosPredeterminados() {
        // Añadir algunos productos de ejemplo
        productos.add(new Producto("Laptop", "Portátil de alta performance", 1200.00, 10));
        productos.add(new Producto("Smartphone", "Teléfono inteligente último modelo", 800.00, 15));
        productos.add(new Producto("Auriculares", "Auriculares inalámbricos con noise cancelling", 250.00, 20));
        productos.add(new Producto("Tablet", "Tablet de 10 pulgadas", 500.00, 8));
        productos.add(new Producto("Smartwatch", "Reloj inteligente con monitor de salud", 300.00, 12));
    }

    public void agregarProducto(Producto producto) {
        if (producto != null) {
            productos.add(producto);
        }
    }

    public List<Producto> obtenerProductos() {
        return new ArrayList<>(productos); // Devuelve una copia para evitar modificaciones directas
    }

    public void eliminarProducto(Producto producto) {
        productos.remove(producto);
    }

    public void actualizarStock(Producto producto, int cantidadNueva) {
        for (Producto p : productos) {
            if (p.equals(producto)) {
                p.setCantidad(cantidadNueva);
                break;
            }
        }
    }
}
