/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 *
 * @author José Sequeira
 */
import javax.swing.*;
import java.awt.*;
import java.util.List;

class VerProductos extends JFrame {

    public VerProductos(Inventario inventario, Carrito carrito) {
        setTitle("Productos Disponibles");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        JScrollPane scrollPane = new JScrollPane(panel);

        for (Producto producto : inventario.obtenerProductos()) {
            JPanel productoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel labelProducto = new JLabel(producto.toString());
            JButton botonAgregar = new JButton("Agregar al Carrito");

            botonAgregar.addActionListener(e -> {
                carrito.agregarProducto(producto);
                JOptionPane.showMessageDialog(this,
                        producto.getNombre() + " agregado al carrito",
                        "Carrito",
                        JOptionPane.INFORMATION_MESSAGE);
            });

            productoPanel.add(labelProducto);
            productoPanel.add(botonAgregar);
            panel.add(productoPanel);
        }

        add(scrollPane);
    }
}
