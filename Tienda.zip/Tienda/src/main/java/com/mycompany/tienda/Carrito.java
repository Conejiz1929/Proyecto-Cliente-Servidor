/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author José Sequeira
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Carrito {

    private List<Producto> productosEnCarrito;

    public Carrito() {
        productosEnCarrito = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productosEnCarrito.add(producto);
    }

    public void eliminarProducto(Producto producto) {
        productosEnCarrito.remove(producto);
    }

    public List<Producto> obtenerProductos() {
        return new ArrayList<>(productosEnCarrito);
    }

    public double calcularTotal() {
        return productosEnCarrito.stream()
                .mapToDouble(Producto::getPrecio)
                .sum();
    }
}
