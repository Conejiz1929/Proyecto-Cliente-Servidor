/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author José Sequeira
 */
import java.util.HashMap;
import java.util.Map;

class GestorUsuarios {

    private Map<String, Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new HashMap<>();
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.put(usuario.getEmail(), usuario);
    }

    public Usuario obtenerUsuario(String email) {
        return usuarios.get(email);
    }

    public boolean autenticarUsuario(String email, String password) {
        Usuario usuario = usuarios.get(email);
        return usuario != null && usuario.getPassword().equals(password);
    }
}
