/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author Conej
 */
public class Cliente {

    private String id;
    private String nombre;
    private String email;
    private String password;
    private boolean esFrecuente;

    public Cliente(String id, String nombre, String email, String password, boolean esFrecuente) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.esFrecuente = esFrecuente;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public boolean isEsFrecuente() {
        return esFrecuente;
    }
}
