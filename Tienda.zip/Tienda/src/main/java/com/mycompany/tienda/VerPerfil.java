/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author José Sequeira
 */
import java.awt.GridLayout;
import javax.swing.*;

class VerPerfil extends JFrame {

    public VerPerfil(Usuario usuario) {
        setTitle("Perfil de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Nombre: " + usuario.getNombre()));
        panel.add(new JLabel("Email: " + usuario.getEmail()));

        add(panel);
    }
}
