/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ControlDeInventarioyProductos;

/**
 *
 * @author José Sequeira
 */
public class Promocion {

    private String id;
    private String descripcion;
    private double descuento;

    public Promocion(String id, String descripcion, double descuento) {
        this.id = id;
        this.descripcion = descripcion;
        this.descuento = descuento;
    }

    // Getters y setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
}
